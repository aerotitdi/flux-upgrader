# qwen-bridge — бесплатный Qwen3.8-Max в Open WebUI через chat.qwen.ai

Локальный мост-прокси: для Open WebUI он выглядит как обычный OpenAI API
(`/v1/models`, `/v1/chat/completions`, стриминг), а сам разговаривает с **нативным
web-API сайта chat.qwen.ai** под токеном вашего бесплатного аккаунта.
Токен не покидает вашу машину.

```
Open WebUI  --OpenAI API-->  qwen_bridge.py (localhost:8000)  --web API v2-->  chat.qwen.ai
```

## Почему «что-то не то» и зачем мост

- **OpenRouter** (у вас уже подключён): `qwen3.8-max` там **платный** (~$2/$6 за млн
  токенов), бесплатно дают только open-weight модели вроде `qwen3.8-27b:free` — это не Max.
- **chat.qwen.ai** — бесплатный, но **официального публичного API у веб-версии нет**:
  сайт использует внутреннее API v2 с JWT-токеном и антиботом Aliyun WAF.
  Поэтому URL сайта нельзя просто вставить в Open WebUI — соединения не будет.
- Мост решает именно это: транслирует OpenAI-формат в web-API сайта и обратно
  (включая стриминг и «рассуждения» модели).
- Существует публичный хост-прокси `qwen.aikit.club` (проект encryptarun/qwen-api),
  но туда придётся отдавать свой токен чужому серверу. Локальный мост — безопаснее.

## Шаг 0. Требования

Python 3.10+ и одна зависимость:

```bash
cd qwen-bridge
pip install -r requirements.txt
```

## Шаг 1. Получить токен chat.qwen.ai

1. Войдите в аккаунт на https://chat.qwen.ai/
2. Нажмите F12 → вкладка Console → вставьте содержимое `token_snippet.js` → Enter.
3. Токен (JWT, начинается с `eyJ...`) попадёт в буфер обмена и в консоль.

Токен — это фактически пароль от аккаунта: храните его в env-переменной, не коммитьте.
Живёт он порядка месяца; получите 401 — просто повторите шаг 1.

## Шаг 2. Запустить мост

Windows (cmd):

```cmd
cd C:\Users\User\Desktop\qwen-bridge
py -m pip install -r requirements.txt
set QWEN_TOKEN=eyJ...
py qwen_bridge.py
```

(в PowerShell вместо `set` — `$env:QWEN_TOKEN="eyJ..."`; `requirements.txt` не запускают,
его устанавливают через `pip install -r`).

Linux/macOS:

```bash
cd qwen-bridge
pip install -r requirements.txt
QWEN_TOKEN="eyJ..." python qwen_bridge.py
```

Переменные окружения:

| Переменная | По умолчанию | Смысл |
|---|---|---|
| `QWEN_TOKEN` | — | JWT из шага 1 (обязателен) |
| `QWEN_HOST` / `QWEN_PORT` | `127.0.0.1` / `8000` | где слушать |
| `QWEN_API_KEY` | — | если задать — Open WebUI должен присылать этот ключ |
| `QWEN_DEFAULT_MODEL` | `qwen3.8-max` | модель по умолчанию и первая в списке |
| `QWEN_THINKING_MODE` | `Auto` | `Auto` / `Thinking` / `Fast` (Fast = без рассуждений) |
| `QWEN_CLEAN_CHATS` | `1` | удалять временные чаты из сайдбара сайта после ответа |
| `QWEN_COOKIE` | — | полный заголовок Cookie из браузера (если WAF упрётся, см. troubleshooting) |
| `QWEN_BASE_URL` | `https://chat.qwen.ai` | не трогать (нужен для тестов с моком) |

Для автозапуска удобно положить в systemd-юнит или просто в `nohup`.

## Шаг 3. Подключить в Open WebUI

Как на вашем скриншоте: **Админ-панель → Подключения → API OpenAI → «+»**:

- **URL:** `http://host.docker.internal:8000/v1` — если Open WebUI крутится в Docker,
  а мост на хосте (у вас именно так: Ollama же подключена через `host.docker.internal`).
  Если Open WebUI не в Docker — `http://localhost:8000/v1`.
  **Обязательно с суффиксом `/v1`** — частая причина «connection error».
- **Тип API:** `Chat Completions` (НЕ «Ответы»/Responses — мост их не реализует).
- **Ключ API:** любой, например `sk-qwen-free` (мост его не проверяет, пока не задан `QWEN_API_KEY`).
- **IDs модели:** оставьте пустыми — подтянутся все модели из `/v1/models`.

После сохранения список моделей подтянется сам из `/v1/models` (`qwen3.8-max` первым).
Если модели не появились: в настройках этого соединения вручную добавьте ID модели
`qwen3.8-max` (так же, как вы добавляли `nvidia/nemotron-3-ultra-550b-a55b:free`),
либо снимите галочку «Кэшировать список базовых моделей» и пересохраните.

## Шаг 4. Проверка

```bash
curl http://localhost:8000/v1/health
curl http://localhost:8000/v1/models
curl http://localhost:8000/v1/chat/completions -H 'Content-Type: application/json' \
  -d '{"model":"qwen3.8-max","messages":[{"role":"user","content":"Привет!"}],"stream":false}'
```

Без токена можно потрогать всю цепочку локально: `python mock_qwen.py` поднимает
имитацию chat.qwen.ai на :9999, затем
`QWEN_BASE_URL=http://127.0.0.1:9999 QWEN_TOKEN=x python qwen_bridge.py`.

## Модели и бонус-режимы

- Список моделей берётся живьём с сайта (`/api/models`): все чат-модели, включая
  спец-режимы (`qwen-deep-research`, `qwen-web-dev` и т.п., если сайт их отдаёт).
  Переключаются они в выборщике моделей Open WebUI как обычно.
- **Суффиксы к ID модели** (писать прямо в выборщике или добавить как IDs модели в соединении):
  - `qwen3.8-max:search` — нативный поиск в интернете (chat_type `search`);
    для моделей с поиском мост сам публикует отдельную запись `…:search` в `/v1/models`;
  - `qwen3.8-max:think` — форсировать рассуждения (Thinking);
  - `qwen3.8-max:fast` — без рассуждений, ответ быстрее.
  Дефолтный режим рассуждений задаётся переменной `QWEN_THINKING_MODE` (Auto/Thinking/Fast).
- **Про «режим агента» честно:** нативного function calling (OpenAI `tools`) в web-API
  chat.qwen.ai нет, поэтому встроенные тулзы/агент-режим Open WebUI через мост напрямую
  не заработают. Замена-максимум из коробки — `:search` и `qwen-deep-research`
  (сайт сам ищет и собирает ответ). Если очень хочется именно тулзы OWUI — могу добавить
  в мост prompt-эмуляцию function calling (костыль, может ломаться); нативно тулзы
  поддерживают платный OpenRouter и DashScope с бесплатной квотой.

## Как это устроено внутри

- На каждый запрос Open WebUI мост создаёт временный чат `POST /api/v2/chats/new`,
  отправляет историю цепочкой сообщений (`fid`/`parentId`) в
  `POST /api/v2/chat/completions?chat_id=...` и читает SSE-поток
  (`phase: think` → `reasoning_content`, `phase: answer` → `content`).
  После ответа чат удаляется, чтобы не засорять сайдбар (`QWEN_CLEAN_CHATS=0` отключает).
- Если сайт откажется принимать полную историю — мост автоматически повторяет запрос
  только с последним сообщением.
- Антибот: браузерные заголовки, `source: web`, `bx-umidtoken` добывается из
  `sg-wum.alibaba.com/wu.json` и перевыпускается при 429.
- 429 = лимиты бесплатного аккаунта: мост сделает 3 повтора с паузой,
  но параллельные потоки запросов лучше не устраивать.

## Troubleshooting («что-то не то» чек-лист)

| Симптом | Что делать |
|---|---|
| Open WebUI: connection error | URL обязательно с `/v1`; мост запущен; из Docker-контейнера хост виден как `host.docker.internal` |
| 401/403 от chat.qwen.ai | токен протух — повторить шаг 1 |
| Ошибка «upstream вернул HTML (WAF)» | задать `QWEN_COOKIE`: DevTools → Network → любой запрос к chat.qwen.ai → скопировать значение заголовка `Cookie` целиком |
| В Open WebUI пусто в списке моделей | добавить ID модели вручную / отключить кэш списка моделей |
| Ответ без «рассуждений» или слишком «думает» | `QWEN_THINKING_MODE=Fast` или `Thinking` |
| Сайдбар сайта засоряется чатами | `QWEN_CLEAN_CHATS=1` (по умолчанию уже так) |

## Честно про риски и альтернативы

- Это **неофициальный** интерфейс веб-версии: серая зона ToS, может сломаться после
  обновления сайта. Используйте для себя и без злоупотреблений (без параллельных вееров запросов).
- Официальные бесплатные пути, если мост сломается: `:free`-модели OpenRouter
  (`qwen3.8-27b:free` — open-weight, не Max) и бесплатный квот новичка в Alibaba
  Model Studio / DashScope (OpenAI-совместимый endpoint, подключается в Open WebUI напрямую).

## Файлы

- `qwen_bridge.py` — сам мост (один файл, зависимость aiohttp)
- `token_snippet.js` — извлечение токена из браузера
- `mock_qwen.py` — имитация chat.qwen.ai для тестов без токена
- `requirements.txt`, `README.md`
