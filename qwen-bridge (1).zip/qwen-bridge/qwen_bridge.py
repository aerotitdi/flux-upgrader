#!/usr/bin/env python3
"""
qwen_bridge.py — локальный мост Open WebUI -> chat.qwen.ai (бесплатно).

Поднимает OpenAI-совместимый API (/v1/models, /v1/chat/completions, SSE-stream),
а сам ходит в нативный Web API chat.qwen.ai (api/v2) с токеном вашего бесплатного
аккаунта. Токен никуда не уходит с вашей машины.

Запуск:
    pip install aiohttp
    QWEN_TOKEN="eyJ..." python qwen_bridge.py

Порт/хост: QWEN_HOST (127.0.0.1), QWEN_PORT (8000).
Подробности — в README.md.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import time
import uuid
from typing import Any, AsyncIterator, Optional

import aiohttp
from aiohttp import web

# --------------------------------------------------------------------------- config

BASE_URL = os.environ.get("QWEN_BASE_URL", "https://chat.qwen.ai").rstrip("/")
HOST = os.environ.get("QWEN_HOST", "127.0.0.1")
PORT = int(os.environ.get("QWEN_PORT", "8000"))
TOKEN = os.environ.get("QWEN_TOKEN", "").strip()
RAW_COOKIE = os.environ.get("QWEN_COOKIE", "").strip()          # опционально: полный Cookie из браузера
BRIDGE_API_KEY = os.environ.get("QWEN_API_KEY", "").strip()      # опционально: ключ, который ждёт Open WebUI
CLEAN_CHATS = os.environ.get("QWEN_CLEAN_CHATS", "1") != "0"     # удалять созданные чаты из сайдбара
THINKING_MODE = os.environ.get("QWEN_THINKING_MODE", "Auto")     # Auto | Thinking | Fast
DEFAULT_MODEL = os.environ.get("QWEN_DEFAULT_MODEL", "qwen3.8-max")
MODELS_TTL = int(os.environ.get("QWEN_MODELS_TTL", "3600"))
WUM_URL = "https://sg-wum.alibaba.com/w/wu.json"

FALLBACK_MODELS = [
    "qwen3.8-max", "qwen3.8-omni-flash", "qwen3.7-max", "qwen3.7-plus",
    "qwen3.6-plus", "qwen3.5-plus", "qwen3-coder-plus", "qwen3-vl-plus",
]

UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36")


def base_headers() -> dict[str, str]:
    h = {
        "User-Agent": UA,
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Origin": BASE_URL,
        "Referer": BASE_URL + "/",
        "Content-Type": "application/json",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "Connection": "keep-alive",
        "X-Requested-With": "XMLHttpRequest",
        "source": "web",
        "version": "0.2.63",
        "X-Accel-Buffering": "no",   # лечит FAIL_SYS_USER_VALIDATE на некоторых прокси
    }
    if RAW_COOKIE:
        h["Cookie"] = RAW_COOKIE
    if TOKEN:
        h["Authorization"] = f"Bearer {TOKEN}"
    return h


# --------------------------------------------------------------------------- anti-bot

class Midtoken:
    """bx-umidtoken — антибот-маркер Aliyun WAF. Добывается из wu.json, кэшируется."""

    def __init__(self) -> None:
        self._value: Optional[str] = None
        self._lock = asyncio.Lock()

    async def get(self, session: aiohttp.ClientSession, force: bool = False) -> Optional[str]:
        async with self._lock:
            if self._value and not force:
                return self._value
            try:
                async with session.get(WUM_URL, timeout=aiohttp.ClientTimeout(total=10)) as r:
                    text = await r.text()
                m = re.search(r"(?:umx\.wu|__fycb)\('([^']+)'\)", text)
                self._value = m.group(1) if m else None
            except Exception as exc:  # noqa: BLE001
                log(f"WARN: не удалось получить bx-umidtoken: {exc}")
                self._value = None
            return self._value

    def invalidate(self) -> None:
        self._value = None


MIDTOKEN = Midtoken()


async def req_headers(session: aiohttp.ClientSession, force_mid: bool = False) -> dict[str, str]:
    h = base_headers()
    mid = await MIDTOKEN.get(session, force=force_mid)
    if mid:
        h["bx-umidtoken"] = mid
        h["bx-v"] = "2.5.36"
    h["x-request-id"] = str(uuid.uuid4())
    return h


# --------------------------------------------------------------------------- models

TEXTISH = ("t2t", "search", "deep_research", "web_dev", "full_stack", "artifacts")


class ModelsCache:
    def __init__(self) -> None:
        self.ids: list[str] = []
        self.meta: dict[str, list[str]] = {}
        self.ts = 0.0

    async def get(self, session: aiohttp.ClientSession) -> list[str]:
        if self.ids and time.time() - self.ts < MODELS_TTL:
            return self.ids
        try:
            h = base_headers()
            h["x-request-id"] = str(uuid.uuid4())
            async with session.get(f"{BASE_URL}/api/models", headers=h,
                                   timeout=aiohttp.ClientTimeout(total=15)) as r:
                if r.status == 200:
                    data = (await r.json()).get("data", [])
                    ids, meta = [], {}
                    for m in data:
                        types = ((m.get("info") or {}).get("meta") or {}).get("chat_type") or []
                        if any(t in TEXTISH for t in types):
                            ids.append(m["id"])
                            meta[m["id"]] = list(types)
                    if ids:
                        self.ids, self.meta, self.ts = ids, meta, time.time()
                        log(f"models: получено {len(ids)} моделей с {BASE_URL}")
                        return self.ids
        except Exception as exc:  # noqa: BLE001
            log(f"WARN: /api/models недоступен: {exc}")
        if not self.ids:
            self.ids = list(FALLBACK_MODELS)
            self.meta = {i: ["t2t", "search"] for i in self.ids}
            self.ts = time.time()
        return self.ids

    def types(self, model_id: str) -> list[str]:
        return self.meta.get(model_id, ["t2t"])


MODELS = ModelsCache()

SUFFIXES = ("search", "think", "fast")


def parse_model(model: str) -> tuple[str, Optional[str]]:
    """'qwen3.8-max:search' -> ('qwen3.8-max', 'search')."""
    if ":" in model:
        base, suf = model.rsplit(":", 1)
        if suf in SUFFIXES:
            return base, suf
    return model, None


def resolve_chat_type(types: list[str], suffix: Optional[str]) -> str:
    if suffix == "search" and "search" in types:
        return "search"
    for t in ("t2t", "deep_research", "web_dev", "full_stack", "artifacts"):
        if t in types:
            return t
    return "t2t"


# --------------------------------------------------------------------------- helpers

def log(msg: str) -> None:
    print(f"[qwen-bridge] {msg}", flush=True)


def openai_error(message: str, code: int = 502, etype: str = "upstream_error") -> web.Response:
    return web.json_response(
        {"error": {"message": message, "type": etype, "code": code}}, status=code)


def check_bridge_auth(request: web.Request) -> Optional[web.Response]:
    if not BRIDGE_API_KEY:
        return None
    auth = request.headers.get("Authorization", "")
    key = auth[7:] if auth.startswith("Bearer ") else request.headers.get("x-api-key", "")
    if key == BRIDGE_API_KEY:
        return None
    return openai_error("invalid bridge api key", 401, "auth_error")


def content_to_text(content: Any) -> str:
    """OpenAI content: str | list[parts] -> plain text."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for p in content:
            if isinstance(p, dict):
                if p.get("type") == "text" and p.get("text"):
                    parts.append(p["text"])
                elif p.get("type") in ("image_url", "image", "audio", "video", "file"):
                    parts.append("[вложение не поддерживается мостом v1]")
            elif isinstance(p, str):
                parts.append(p)
        return "\n".join(parts)
    return str(content)


def build_qwen_messages(openai_messages: list[dict], model: str, chat_type: str = "t2t",
                        thinking_mode: Optional[str] = None) -> list[dict]:
    """OpenAI messages -> цепочка сообщений web-API Qwen (fid/parentId)."""
    system_chunks: list[str] = []
    chain: list[dict] = []
    parent: Optional[str] = None
    now = int(time.time() * 1000)

    for i, m in enumerate(openai_messages):
        role = (m.get("role") or "user").lower()
        text = content_to_text(m.get("content"))
        if role == "system":
            system_chunks.append(text)
            continue
        if role not in ("user", "assistant"):
            text = f"[{role}] {text}"
            role = "user"
        if role == "user" and system_chunks and not chain:
            text = "[System instructions]\n" + "\n".join(system_chunks) + "\n\n" + text
        fid = str(uuid.uuid4())
        chain.append({
            "fid": fid,
            "parentId": parent,
            "childrenIds": [],
            "role": role,
            "content": text,
            "user_action": "chat",
            "files": [],
            "timestamp": now + i,
            "models": [model],
            "chat_type": chat_type,
            "sub_chat_type": chat_type,
            "extra": {"meta": {"subChatType": chat_type}},
        })
        parent = fid

    if system_chunks and not chain:
        fid = str(uuid.uuid4())
        chain.append({
            "fid": fid, "parentId": None, "childrenIds": [], "role": "user",
            "content": "\n".join(system_chunks), "user_action": "chat", "files": [],
            "timestamp": now, "models": [model], "chat_type": chat_type,
            "sub_chat_type": chat_type, "extra": {"meta": {"subChatType": chat_type}},
        })
    if not chain:
        raise ValueError("пустой messages")

    enable_thinking = (thinking_mode or THINKING_MODE).strip().lower() != "fast"
    mode = (thinking_mode or THINKING_MODE).strip().lower()
    if enable_thinking:
        feature_config = {
            "auto_thinking": mode == "auto",
            "thinking_mode": "Thinking" if mode == "thinking" else "Auto",
            "thinking_enabled": True,
            "output_schema": "phase",
            "research_mode": "normal",
            "auto_search": True,
        }
    else:
        feature_config = {"thinking_enabled": False, "output_schema": "phase",
                          "thinking_budget": 81920}
    chain[-1]["feature_config"] = feature_config
    return chain


def completion_payload(model: str, chat_id: str, qwen_msgs: list[dict], stream: bool) -> dict:
    now = int(time.time() * 1000)
    return {
        "stream": stream,
        "version": "2.1",
        "incremental_output": stream,
        "chat_id": chat_id,
        "chat_mode": "normal",
        "model": model,
        "parent_id": qwen_msgs[-1]["parentId"],
        "messages": qwen_msgs,
        "timestamp": now,
    }


# --------------------------------------------------------------------------- upstream calls

async def create_chat(session: aiohttp.ClientSession, model: str) -> str:
    payload = {
        "title": "New Chat",
        "models": [model],
        "chat_mode": "normal",
        "chat_type": "t2t",
        "timestamp": int(time.time() * 1000),
        "project_id": "",
    }
    async with session.post(f"{BASE_URL}/api/v2/chats/new", json=payload,
                            headers=await req_headers(session)) as r:
        await raise_upstream(r)
        data = await r.json()
    if not (data.get("success") and (data.get("data") or {}).get("id")):
        raise RuntimeError(f"chats/new: {json.dumps(data, ensure_ascii=False)[:300]}")
    return data["data"]["id"]


async def delete_chat(session: aiohttp.ClientSession, chat_id: str) -> None:
    try:
        async with session.delete(f"{BASE_URL}/api/v2/chats/{chat_id}",
                                  headers=await req_headers(session),
                                  timeout=aiohttp.ClientTimeout(total=15)) as r:
            await r.read()
    except Exception:  # noqa: BLE001
        pass


async def raise_upstream(r: aiohttp.ClientResponse) -> None:
    ct = r.headers.get("content-type", "")
    if r.status >= 400:
        body = (await r.text())[:400]
        if r.status in (401, 403):
            raise UpstreamAuth(f"{r.status}: токен отклонён chat.qwen.ai. "
                               f"Обновите токен (README, шаг 1). body={body}")
        if r.status == 429:
            raise UpstreamRateLimit(f"429: rate limit web-аккаунта. body={body}")
        raise RuntimeError(f"upstream HTTP {r.status}: {body}")
    if "text/html" in ct:
        html = (await r.text())[:200]
        raise RuntimeError(f"upstream вернул HTML (WAF/Cloudflare?): {html}")


class UpstreamAuth(RuntimeError):
    pass


class UpstreamRateLimit(RuntimeError):
    pass


async def stream_qwen(session: aiohttp.ClientSession, model: str,
                      qwen_msgs_variants: list[list[dict]]) -> AsyncIterator[dict]:
    """Стримит сырые SSE-чанки web-API. Сам создаёт (и потом чистит) чат."""
    last_exc: Optional[Exception] = None
    for attempt in range(4):
        chat_id: Optional[str] = None
        try:
            variants = qwen_msgs_variants if attempt < len(qwen_msgs_variants) else qwen_msgs_variants[-1:]
            msgs = variants[min(attempt, len(variants) - 1)]
            chat_id = await create_chat(session, model)
            payload = completion_payload(model, chat_id, msgs, stream=True)
            headers = await req_headers(session, force_mid=attempt > 0)
            async with session.post(
                f"{BASE_URL}/api/v2/chat/completions?chat_id={chat_id}",
                json=payload, headers=headers,
                timeout=aiohttp.ClientTimeout(total=None, connect=20, sock_read=300),
            ) as r:
                await raise_upstream(r)
                if "application/json" in r.headers.get("content-type", ""):
                    body = await r.json()
                    raise RuntimeError(f"upstream json: {json.dumps(body, ensure_ascii=False)[:300]}")
                got_any = False
                async for chunk in parse_sse(r):
                    err = chunk.get("error")
                    if err:
                        raise RuntimeError(f"upstream error: {err.get('code')}: {err.get('details')}")
                    if chunk.get("choices") or chunk.get("usage") or "response.created" in chunk:
                        got_any = True
                    yield chunk
                if not got_any:
                    raise RuntimeError("пустой ответ от chat.qwen.ai")
            if CLEAN_CHATS and chat_id:
                asyncio.create_task(delete_chat(session, chat_id))
            return
        except (UpstreamRateLimit, RuntimeError) as exc:
            last_exc = exc
            if chat_id and CLEAN_CHATS:
                asyncio.create_task(delete_chat(session, chat_id))
            retryable = isinstance(exc, UpstreamRateLimit) or "429" in str(exc) or "RateLimited" in str(exc)
            if retryable and attempt < 3:
                MIDTOKEN.invalidate()
                log(f"WARN: rate limit, попытка {attempt + 2} через 2 c")
                await asyncio.sleep(2)
                continue
            if isinstance(exc, UpstreamAuth):
                raise
            if attempt == 0 and len(qwen_msgs_variants) > 1:
                # вторая попытка: только последнее сообщение (без истории)
                log("WARN: повтор с урезанной историей")
                continue
            raise
    raise last_exc or RuntimeError("upstream failed")


async def parse_sse(r: aiohttp.ClientResponse) -> AsyncIterator[dict]:
    buf = ""
    async for raw_chunk in r.content.iter_any():
        buf += raw_chunk.decode("utf-8", errors="replace")
        while "\n" in buf:
            line, buf = buf.split("\n", 1)
            line = line.strip("\r")
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if not payload or payload == "[DONE]":
                continue
            try:
                yield json.loads(payload)
            except json.JSONDecodeError:
                continue


# --------------------------------------------------------------------------- openai layer

def chunk_envelope(cid: str, model: str, delta: dict, finish: Optional[str] = None,
                   usage: Optional[dict] = None) -> dict:
    return {
        "id": cid,
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": model,
        "choices": [{"index": 0, "delta": delta, "finish_reason": finish}],
        **({"usage": usage} if usage else {}),
    }


def map_usage(u: Optional[dict]) -> dict:
    u = u or {}
    prompt = u.get("prompt_tokens") or u.get("input_tokens") or 0
    comp = u.get("completion_tokens") or u.get("output_tokens") or 0
    return {"prompt_tokens": prompt, "completion_tokens": comp,
            "total_tokens": u.get("total_tokens") or (prompt + comp)}


async def handle_chat_completions(request: web.Request) -> web.StreamResponse:
    deny = check_bridge_auth(request)
    if deny:
        return deny
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return openai_error("bad json", 400, "invalid_request_error")

    model_raw = body.get("model") or DEFAULT_MODEL
    messages = body.get("messages") or []
    stream = bool(body.get("stream", True))
    if not messages:
        return openai_error("messages are empty", 400, "invalid_request_error")
    if not TOKEN and not RAW_COOKIE:
        return openai_error(
            "мост запущен без QWEN_TOKEN: задайте токен chat.qwen.ai (README, шаг 1)",
            500, "configuration_error")

    model, suffix = parse_model(model_raw)
    session: aiohttp.ClientSession = request.app["session"]
    await MODELS.get(session)
    chat_type = resolve_chat_type(MODELS.types(model), suffix)
    thinking_mode = {"think": "Thinking", "fast": "Fast"}.get(suffix)

    try:
        qwen_msgs = build_qwen_messages(messages, model, chat_type, thinking_mode)
    except Exception as exc:  # noqa: BLE001
        return openai_error(str(exc), 400, "invalid_request_error")

    # вариант B: только последнее user-сообщение (fallback, если историю не примет)
    last_user = [m for m in qwen_msgs if m["role"] == "user"][-1:]
    if last_user and last_user[0] is not qwen_msgs[-1]:
        solo = [dict(last_user[0], parentId=None)]
    else:
        solo = [dict(qwen_msgs[-1], parentId=None)]
    variants = [qwen_msgs, solo] if len(qwen_msgs) > 1 else [qwen_msgs]

    cid = f"chatcmpl-{uuid.uuid4().hex[:24]}"

    if not stream:
        text_parts: list[str] = []
        reason_parts: list[str] = []
        usage: Optional[dict] = None
        thinking = False
        try:
            async for ch in stream_qwen(session, model, variants):
                usage = ch.get("usage", usage)
                for choice in ch.get("choices", []):
                    delta = choice.get("delta") or {}
                    phase, content = delta.get("phase"), delta.get("content")
                    if not content:
                        continue
                    if phase == "think":
                        thinking = True
                        reason_parts.append(content)
                    elif phase == "answer":
                        thinking = False
                        text_parts.append(content)
                    else:
                        (reason_parts if thinking else text_parts).append(content)
        except UpstreamAuth as exc:
            return openai_error(str(exc), 401, "auth_error")
        except Exception as exc:  # noqa: BLE001
            return openai_error(str(exc), 502)
        message = {"role": "assistant", "content": "".join(text_parts)}
        if reason_parts:
            message["reasoning_content"] = "".join(reason_parts)
        return web.json_response({
            "id": cid, "object": "chat.completion", "created": int(time.time()),
            "model": model_raw, "choices": [{"index": 0, "message": message,
                                         "finish_reason": "stop"}],
            "usage": map_usage(usage),
        })

    # ------- streaming -------
    resp = web.StreamResponse(status=200, headers={
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
        "Connection": "keep-alive",
    })
    await resp.prepare(request)

    async def send(obj: dict) -> None:
        await resp.write(f"data: {json.dumps(obj, ensure_ascii=False)}\n\n".encode())

    await send(chunk_envelope(cid, model_raw, {"role": "assistant", "content": ""}))
    usage: Optional[dict] = None
    try:
        async for ch in stream_qwen(session, model, variants):
            usage = ch.get("usage", usage)
            for choice in ch.get("choices", []):
                delta = choice.get("delta") or {}
                phase, content = delta.get("phase"), delta.get("content")
                if not content:
                    continue
                if phase == "think":
                    await send(chunk_envelope(cid, model_raw, {"reasoning_content": content}))
                elif phase == "answer":
                    await send(chunk_envelope(cid, model_raw, {"content": content}))
                else:
                    await send(chunk_envelope(cid, model_raw, {"content": content}))
        await send(chunk_envelope(cid, model_raw, {}, finish="stop", usage=map_usage(usage)))
        await resp.write(b"data: [DONE]\n\n")
    except (UpstreamAuth, RuntimeError, aiohttp.ClientError) as exc:
        err = {"error": {"message": str(exc), "type": "upstream_error",
                         "code": 401 if isinstance(exc, UpstreamAuth) else 502}}
        await send(err)
    except (ConnectionResetError, asyncio.CancelledError):
        pass
    await resp.write_eof()
    return resp


async def handle_models(request: web.Request) -> web.Response:
    deny = check_bridge_auth(request)
    if deny:
        return deny
    ids = await MODELS.get(request.app["session"])
    out: list[str] = []
    for i in ids:
        out.append(i)
        if "search" in MODELS.types(i):
            out.append(f"{i}:search")
    if DEFAULT_MODEL in out:
        out = [DEFAULT_MODEL] + [i for i in out if i != DEFAULT_MODEL]
    return web.json_response({
        "object": "list",
        "data": [{"id": i, "object": "model", "created": int(time.time()),
                  "owned_by": "qwen-web"} for i in out],
    })


async def handle_health(request: web.Request) -> web.Response:
    return web.json_response({
        "status": "ok",
        "base_url": BASE_URL,
        "token_set": bool(TOKEN or RAW_COOKIE),
        "thinking_mode": THINKING_MODE,
        "clean_chats": CLEAN_CHATS,
        "models_cached": len(MODELS.ids),
    })


async def make_app() -> web.Application:
    app = web.Application(client_max_size=8 * 1024 * 1024)
    app["session"] = aiohttp.ClientSession(trust_env=True)
    app.router.add_get("/v1/models", handle_models)
    app.router.add_get("/models", handle_models)
    app.router.add_post("/v1/chat/completions", handle_chat_completions)
    app.router.add_post("/chat/completions", handle_chat_completions)
    app.router.add_get("/v1/health", handle_health)
    app.router.add_get("/health", handle_health)

    async def on_shutdown(_app: web.Application) -> None:
        await _app["session"].close()

    app.on_shutdown.append(on_shutdown)
    return app


def main() -> None:
    log(f"base_url={BASE_URL} token={'set' if TOKEN or RAW_COOKIE else 'MISSING'} "
        f"thinking={THINKING_MODE} clean_chats={CLEAN_CHATS}")
    log(f"Open WebUI connection URL: http://host.docker.internal:{PORT}/v1  (или http://localhost:{PORT}/v1)")
    web.run_app(make_app(), host=HOST, port=PORT, print=lambda *a: None)


if __name__ == "__main__":
    main()
