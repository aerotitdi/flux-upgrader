#!/usr/bin/env python3
"""mock_qwen.py — мини-имитация Web API chat.qwen.ai для локальной проверки моста."""
import json
import uuid
from aiohttp import web

chats = {}


async def models(request):
    return web.json_response({"success": True, "data": [
        {"id": "qwen3.8-max", "info": {"meta": {"chat_type": ["t2t", "search"]}}},
        {"id": "qwen3-coder-plus", "info": {"meta": {"chat_type": ["t2t"]}}},
        {"id": "qwen-deep-research", "info": {"meta": {"chat_type": ["deep_research"]}}},
        {"id": "qwen-image", "info": {"meta": {"chat_type": ["t2i"]}}},
    ]})


async def chats_new(request):
    body = await request.json()
    cid = str(uuid.uuid4())
    chats[cid] = body
    return web.json_response({"success": True, "data": {"id": cid}})


async def chats_delete(request):
    chats.pop(request.match_info["chat_id"], None)
    return web.json_response({"success": True})


async def completions(request):
    body = await request.json()
    assert body.get("chat_id") in chats or True
    n_msgs = len(body.get("messages", []))
    resp = web.StreamResponse(headers={"Content-Type": "text/event-stream"})
    await resp.prepare(request)

    async def emit(obj):
        await resp.write(f"data: {json.dumps(obj, ensure_ascii=False)}\n\n".encode())

    rid = str(uuid.uuid4())
    await emit({"response.created": {"response_id": rid}})
    await emit({"choices": [{"delta": {"phase": "think", "status": "typing",
                                       "content": "(думаю…) "}}]})
    words = f"Привет! История из {n_msgs} сообщений. " \
            f"[upstream model={body.get('model')} chat_type={ (body.get('messages') or [{}])[-1].get('chat_type') }]".split()
    for w in words:
        await emit({"choices": [{"delta": {"phase": "answer", "status": "typing",
                                           "content": w + " "}}]})
    await emit({"choices": [{"delta": {"phase": "answer", "status": "finished",
                                       "content": ""}}],
                "usage": {"prompt_tokens": 10, "completion_tokens": 20,
                          "total_tokens": 30}})
    await resp.write_eof()
    return resp


app = web.Application()
app.router.add_get("/api/models", models)
app.router.add_post("/api/v2/chats/new", chats_new)
app.router.add_delete("/api/v2/chats/{chat_id}", chats_delete)
app.router.add_post("/api/v2/chat/completions", completions)

if __name__ == "__main__":
    web.run_app(app, host="127.0.0.1", port=9999, print=lambda *a: None)
