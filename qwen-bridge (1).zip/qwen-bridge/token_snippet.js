// Вставить в консоль браузера (F12) на открытой странице https://chat.qwen.ai/ (выполненным входом).
// Скопирует access_token в буфер обмена и выведет в консоль.
(function () {
  if (window.location.hostname !== "chat.qwen.ai") {
    console.error("Открой https://chat.qwen.ai/ и запусти скрипт там.");
    return;
  }
  const token = localStorage.getItem("token");
  if (!token) {
    console.error("Токен не найден: сначала войди в аккаунт на chat.qwen.ai");
    return;
  }
  console.log("Твой токен:\n" + token);
  navigator.clipboard.writeText(token).then(
    () => console.log("…и скопирован в буфер обмена ✅"),
    () => console.log("(в буфер не удалось, скопируй из консоли выше)")
  );
})();
